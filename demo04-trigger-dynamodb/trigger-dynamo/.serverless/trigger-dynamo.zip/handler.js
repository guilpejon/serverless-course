module.exports = {
  heroesInsert: require('./src/heroes.insert')
}
