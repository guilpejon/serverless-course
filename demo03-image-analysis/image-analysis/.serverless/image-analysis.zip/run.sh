# invocando a lambda usando um request em arquivo local
sls invoke local -f img-analysis --path request.json
