
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'guilpejon',
  applicationName: 'image-analysis',
  appUid: '4j1JsLbPL5pr728x0T',
  orgUid: '43ce7ad8-4f69-4ec7-8335-e4a6f4261f9d',
  deploymentUid: 'dfcc6d37-9c40-4515-9aa8-b85f2a46e4aa',
  serviceName: 'image-analysis',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'image-analysis-dev-img-analysis', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}